<?php

namespace App\Providers;

use App\Models\UserLevel;
use App\Models\UserTask;
use Asantibanez\LivewireCharts\Models\ColumnChartModel;
use Illuminate\Support\ServiceProvider;

class GraphicsServiceProvider extends ServiceProvider
{
    public static $colors = ['#f6ad55','#fc8181','#90cdf4'];

    /**
     * Get The sum of time in hours of User level
     */
    public static function GraphicIdUserTasks() : ColumnChartModel {
        $userTypes = UserLevel::all();
        $tasksIdLevel = [];
        $columnChartModel = (new ColumnChartModel())->setTitle('Tasks by User Levels');
        foreach($userTypes as $usuType => $ut) {
            $tasksIdLevel[$ut->level] = UserTask::where('id_level',$ut->id)->sum('time_in_hours');
            $columnChartModel->addColumn($ut->level, $tasksIdLevel[$ut->level], self::$colors[$usuType]);
        }
        return  $columnChartModel;
    }
}

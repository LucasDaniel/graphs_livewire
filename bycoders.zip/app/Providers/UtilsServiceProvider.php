<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Nette\Utils\Random;

class UtilsServiceProvider extends ServiceProvider
{
    
}

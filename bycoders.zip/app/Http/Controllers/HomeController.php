<?php

namespace App\Http\Controllers;

use App\Models\TaskType;
use App\Models\User;
use App\Models\UserLevel;
use App\Models\UserTask;
use Illuminate\Contracts\Session\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{

    public function index(Request $request) {

        $err = $request->get('err');

        if($err == 1) $err = "Email and password wrong!"; 
        else if($err == 2) $err = "No access!"; 

        return view('welcome',['err' => $err]);
    }

    public function createRandomTasksUsers() {

        $ids = User::select('id','id_level')->get();
        $u = [];
        foreach($ids as $id => $i) {
            $u[] = [$i->id,$i->id_level];
        }
        $taskType = TaskType::all();
        $tt = [];
        foreach($taskType as $taskT => $t) {
            $tt[] = $t->id;
        }
        $maximo = rand(1000,2000);
        for($i = 0; $i < $maximo; $i++) {
            $userTask = new UserTask();
            $userTask->id_user = $u[rand(0,count($u)-1)][0];
            $userTask->id_level = $u[rand(0,count($u)-1)][1];
            $userTask->id_task = $tt[rand(0,count($tt)-1)];
            $userTask->time_in_hours = rand(1,8);
            $userTask->save();
        }
        dd(UserTask::all());
    }

    public function login(Request $request) {

        $rules = [
            'email' => 'email',
            'password' => 'required'
        ];

        $feedback = [
            'user.email' => 'Email is mandatory',
            'user.password' => 'Password is mandatory',
        ];

        $request->validate($rules,$feedback);

        $email = $request->get('email');
        $password = $request->get('password');

        $user = new User();
        $user = $user->where('email',$email)
                       ->get()->first();

        if (isset($user->name)) {
            if (Hash::check($password, $user->password)) {


                session(['id_user' => $user->id]);
                session(['id_level' => $user->id_level]);
                session(['level' => UserLevel::where('id',$user->id_level)->first()->level]);
                session(['name' => $user->name]);
                session(['email' => $user->email]);
                
                return redirect()->route('app.home');
            } else {
                return redirect()->route('app.index',[ 'err' => 1 ]);
            }
        } else {
            return redirect()->route('app.index',[ 'err' => 1 ]);
        }
    }

    public function home() {
        return view('home');
    }

    public function logout() {
        $this->forgetAllSessions();
        return redirect()->to('/');
    }

    private function forgetAllSessions() {
        session()->forget('id_user');
        session()->forget('id_level');
        session()->forget('level');
        session()->forget('name');
        session()->forget('email');
    }

}

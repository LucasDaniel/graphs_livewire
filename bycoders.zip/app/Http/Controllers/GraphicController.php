<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Asantibanez\LivewireCharts\Models\ColumnChartModel;
use App\Models\User;
use App\Models\UserLevel;
use App\Providers\GraphicsServiceProvider;

class GraphicController extends Controller
{
    public function index() {
        return view('graphics', ['chart' => GraphicsServiceProvider::GraphicIdUserTasks()]);
    }
}
